Pimp my Log 
===========

All informations are available on [pimpmylog.com](http://pimpmylog.com).

Please do not open issues on GitHub, this is for dev only.  
Support, FAQ, knowledge base, ... are on [support.pimpmylog.com](http://support.pimpmylog.com).

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/potsky/pimpmylog/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
