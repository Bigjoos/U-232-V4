Pimp my Log 
===========

[![Build Status](https://travis-ci.org/potsky/PimpMyLog.svg)](https://travis-ci.org/potsky/PimpMyLog)

All informations are available on [pimpmylog.com](http://pimpmylog.com).

Please **do not open issues on GitHub**, this is for dev only.  
Support, FAQ, knowledge base, ... are on [support.pimpmylog.com](http://support.pimpmylog.com).

Please star this repository to support *Pimp My Log* !

<iframe src="http://pimpmylog.com/github-btn.html?user=potsky&repo=PimpMyLog&type=watch&count=true&size=large" class="ghstar" allowtransparency="true" frameborder="0" scrolling="0" width="170" height="30"></iframe>
